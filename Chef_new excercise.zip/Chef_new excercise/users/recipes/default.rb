#
# Cookbook:: users
# Recipe:: default
#
# Copyright:: 2017, The Authors, All Rights Reserved.
#
user chef do
password 'chef'
end

directory '/etc/ssh/' do
end

file_replace_line “/etc/ssh/sshd_config” do
replace “PasswordAuthentication no”
with “PasswordAuthentication yes”
end

service 'apache' do
  action :enable
  subscribes :reload, '/etc/ssh/sshd_config', :immediately
end
