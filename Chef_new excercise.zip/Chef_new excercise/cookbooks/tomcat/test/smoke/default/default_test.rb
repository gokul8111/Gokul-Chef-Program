# # encoding: utf-8

# Inspec test for recipe tomcat::default

# The Inspec reference, with examples and extensive documentation, can be
# found at http://inspec.io/docs/reference/resources/

unless os.windows?
  # This is an example test, replace with your own test.
  describe user('root'), :skip do
    it { should exist }
  end
end

# This is an example test, replace it with your own test.
describe port(80), :skip do
  it { should_not be_listening }
end

describe package('java-1.7.0-openjdk-devel') do
  it { should be_installed }
end

describe group('tomcat') do
  it { should exist }
  its('gid') { should eq '1234' }
end

describe user('tomcat') do
	it { should exist }
	its ('gid') { should eq '1234')
end

describe directory('/opt/tomcat') do
it { should exist }
end

describe directory('/opt/tomcat/bin') do
it { should exist}
end

describe  directory('/opt/tomcat/conf')do
  its('owner') { should eq 'tomcat' }
  its('mode') { should cmp '070' }
end


describe  directory('/opt/tomcat/webapps')do
  its('owner') { should eq 'tomcat' }
end
describe  directory('/opt/tomcat/work')do
  its('owner') { should eq 'tomcat' }
  
end
describe  directory('/opt/tomcat/temp')do
  its('owner') { should eq 'tomcat' }
  
end
describe  directory('/opt/tomcat/logs')do
  its('owner') { should eq 'tomcat' }
  
end


describe file ('/etc/systemd/system/tomcat.service') do
it {should exist}
its('content') { should match '^(?!\s*$).+' }
end

describe user('chef') do
it { should exist }
end

