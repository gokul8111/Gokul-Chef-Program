package 'java-1.7.0-openjdk-devel' do

end

group 'tomcat' do
gid 42
end

user "tomcat" do
  home "/home/tomcat"
  shell "/bin/bash" 
end 
directory '/tmp' do
end

remote_file "/tmp/apachetomcat8.tar.gz" do
   source "http://ftp.wayne.edu/apache/tomcat/tomcat-8/v8.5.20/bin/apache-tomcat-8.5.20.tar.gz"
end

directory '/opt/tomcat' do
end

execute 'tar xvf /tmp/apachetomcat8.tar.gz -C /opt/tomcat --strip-components=1'

directory 'opt/tomcat/conf' do
mode '0070'
end
directory 'opt/tomcat/bin' do
mode '0070'
end

execute 'sudo chgrp -R tomcat opt/tomcat/conf' do
  user "root"
  action :run
end

execute 'sudo chmod g+r /opt/tomcat/conf/*' do
user "root"
end
execute 'sudo chown -R tomcat /opt/tomcat/webapps/ /opt/tomcat/work /opt/tomcat/temp/ /opt/tomcat/logs' do
user "root"
end
execute 'sudo chgrp -R tomcat bin' do
user "root"
end
execute 'sudo chgrp -R tomcat lib' do
user "root"
end
execute 'sudo chmod g+rwx bin' do
user "root"
end
execute 'sudo chmod g+r bin/*' do
user "root"
end

template '/etc/systemd/system/tomcat.service' do
source 'tomcat.service.erb'
end

execute 'systemctl daemon-reload'

service 'tomcat' do
action [:start, :disable]
end



